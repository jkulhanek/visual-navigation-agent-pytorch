

class THORGraphBrowser:
    def __init__(self,
            h5_file_path = None,
            approximating_steps = 1000,
            **kwargs):
        super(THORGraphBrowser, self).__init__()

    def process(self, scene = 'bedroom_04'):
        pass

    def find_shortest_path(self, init, goal):
        pass

    def find_random_walk(self, init, goal):
        pass
